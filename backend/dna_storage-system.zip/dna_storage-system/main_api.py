# main_api.py
import os
import secrets
import hashlib
import shutil

from fastapi import Depends, HTTPException, FastAPI, UploadFile, File, Form
from fastapi.responses import FileResponse
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm

from auth import create_access_token, decode_token
from database import *
from encoder import encode_file, decode_fragments, compute_merkle_root
from blockchain import add_block

app = FastAPI(title="DNA Storage System")

from fastapi.middleware.cors import CORSMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="login")

# ===============================
# AUTH HELPER
# ===============================
def get_current_user(token: str = Depends(oauth2_scheme)):
    username = decode_token(token)
    if not username:
        raise HTTPException(status_code=401, detail="Invalid token")
    user = get_user_by_username(username)
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    return user

# ===============================
# INIT
# ===============================
MAX_FILE_SIZE = 1024 * 1024 * 1024  # 1 GB
init()

OUTPUT_FOLDER = "output_files"
KEY_FOLDER = "key_files"
TOKEN_FOLDER = "token_files"
TEMP_FOLDER = "temp_uploads"
FRAGMENTS_FOLDER = "fragments_storage"

os.makedirs(OUTPUT_FOLDER, exist_ok=True)
os.makedirs(KEY_FOLDER, exist_ok=True)
os.makedirs(TOKEN_FOLDER, exist_ok=True)
os.makedirs(TEMP_FOLDER, exist_ok=True)
os.makedirs(FRAGMENTS_FOLDER, exist_ok=True)

# ===============================
# REGISTER
# ===============================
@app.post("/register_api")
def register_api(username: str = Form(...), email: str = Form(...), password: str = Form(...)):
    success, msg = register_user(username, email, password)
    if not success:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg}

# ===============================
# LOGIN
# ===============================
@app.post("/login")
def login_api(form_data: OAuth2PasswordRequestForm = Depends()):
    user = login_user(form_data.username, form_data.password)
    if not user:
        raise HTTPException(status_code=400, detail="Invalid credentials")
    user_id, username = user
    token = create_access_token({"sub": username})
    return {"access_token": token, "token_type": "bearer"}

# ===============================
# UPLOAD
# ===============================
# ===============================
# UPLOAD (FIXED)
# ===============================
@app.post("/upload")
async def upload_file(file: UploadFile = File(...), current_user=Depends(get_current_user)):

    try:
        temp_path = os.path.join(TEMP_FOLDER, file.filename)

        with open(temp_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)

        size = os.path.getsize(temp_path)
        if size > MAX_FILE_SIZE:
            os.remove(temp_path)
            return {"success": False, "error": "File exceeds 1 GB upload limit"}

        # Encode
        fragments, file_hash, fname = encode_file(temp_path)

        retrieval_key = secrets.token_hex(16)
        key_hash = hashlib.sha256(retrieval_key.encode()).hexdigest()
        file_id = secrets.token_hex(8)
        user_id = current_user[0]

        save_file_metadata(file_id, user_id, fname, key_hash, size)

        frag_folder_path = os.path.join(FRAGMENTS_FOLDER, file_id)
        os.makedirs(frag_folder_path, exist_ok=True)
        save_fragments(file_id, fragments, frag_folder_path)

        add_block(file_id, file_hash)

        merkle_root = compute_merkle_root(fragments)

        os.remove(temp_path)

        print("✅ Upload done:", file_id)

        return {
            "success": True,
            "file_id": file_id,
            "retrieval_key": retrieval_key,
            "merkle_root": merkle_root
        }

    except Exception as e:
        print("UPLOAD ERROR:", str(e))
        return {"success": False, "error": str(e)}

# ===============================
# RETRIEVE (FULLY FIXED)
# ===============================
# ===============================
# RETRIEVE (FIXED FOR FRONTEND)
# ===============================
@app.post("/retrieve")
def retrieve_file(file_id: str = Form(...), key: str = Form(...)):

    meta = get_file_metadata(file_id)
    if not meta:
        raise HTTPException(status_code=404, detail="File not found")

    stored_hash, original_size, fname = meta

    if hashlib.sha256(key.encode()).hexdigest() != stored_hash:
        raise HTTPException(status_code=401, detail="Invalid retrieval key")

    frag_folder_path = os.path.join(FRAGMENTS_FOLDER, file_id)
    fragments = get_file_fragments(file_id, frag_folder_path)
    if not fragments:
        raise HTTPException(status_code=404, detail="Fragments missing")

    try:
        decode_fragments(fragments, fname)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Decoding failed: {str(e)}")

    file_path = os.path.abspath(os.path.join(OUTPUT_FOLDER, fname))

    if not os.path.exists(file_path) or os.path.getsize(file_path) == 0:
        raise HTTPException(status_code=500, detail="File reconstruction failed")

    # 🔥 FIX: Ensure correct headers and filename for frontend download
    return FileResponse(
        path=file_path,
        media_type="application/octet-stream",
        filename=fname,
        headers={"Content-Disposition": f'attachment; filename="{fname}"'}
    )
# ===============================
# DELETE FILE
# ===============================
@app.delete("/delete_file")
def delete_file_api(file_id: str = Form(...), current_user=Depends(get_current_user)):
    user_id = current_user[0]

    # Delete fragments folder as well
    frag_folder_path = os.path.join(FRAGMENTS_FOLDER, file_id)
    if delete_file(file_id, user_id):
        if os.path.exists(frag_folder_path):
            shutil.rmtree(frag_folder_path)
        return {"message": "File deleted successfully"}

    return {"error": "File not found or unauthorized"}

# ===============================
# DELETE ACCOUNT
# ===============================
@app.delete("/delete_account")
def delete_account_api(current_user=Depends(get_current_user)):
    user_id = current_user[0]
    delete_user_account(user_id)

    # Delete all user fragments
    for fid, _ in get_user_files(user_id):
        frag_folder_path = os.path.join(FRAGMENTS_FOLDER, fid)
        if os.path.exists(frag_folder_path):
            shutil.rmtree(frag_folder_path)

    return {"message": "Account deleted successfully"}

# ===============================
# FORGOT PASSWORD
# ===============================
@app.post("/forgot_password")
def forgot_password_api(email: str = Form(...)):
    token = str(secrets.randbelow(900000) + 100000)
    store_reset_token(email, token)
    token_file = f"{email.replace('@','_')}_token.txt"
    path = os.path.join(TOKEN_FOLDER, token_file)
    with open(path, "w") as f:
        f.write(f"Reset Token: {token}")
    return {"message": "Token generated", "file": token_file}

# ===============================
# RESET PASSWORD
# ===============================
@app.post("/reset_password")
def reset_password_api(email: str = Form(...), token: str = Form(...), new_password: str = Form(...)):
    if not verify_reset_token(email, token):
        return {"error": "Invalid or expired token"}
    update_password(email, new_password)
    return {"message": "Password reset successful"}

# ===============================
# GET USER FILES
# ===============================
@app.get("/user_files")
def get_user_files_api(current_user=Depends(get_current_user)):
    user_id = current_user[0]
    files = get_user_files(user_id)
    return {"files": [{"file_id": f[0], "filename": f[1]} for f in files]}

# ===============================
# HOME
# ===============================
@app.get("/")
def home():
    return {"message": "DNA Storage API running"}

# ===============================
# ENTRY
# ===============================
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main_api:app", host="127.0.0.1", port=8000, reload=True)