import random

# =========================
# GC CONTENT
# =========================

def gc_content(seq):
    gc = seq.count("G") + seq.count("C")
    return gc / len(seq)


def balance_gc(seq, lower=0.45, upper=0.55):

    seq = list(seq)

    for i in range(len(seq)):

        gc = gc_content("".join(seq))

        if lower <= gc <= upper:
            break

        if gc < lower:

            if seq[i] in ["A", "T"]:
                seq[i] = random.choice(["G", "C"])

        if gc > upper:

            if seq[i] in ["G", "C"]:
                seq[i] = random.choice(["A", "T"])

    return "".join(seq)


# =========================
# HOMOPOLYMER CONTROL
# =========================

def prevent_homopolymers(seq, max_run=3):

    result = ""
    count = 1

    for i in range(len(seq)):

        if i > 0 and seq[i] == seq[i - 1]:

            count += 1

            if count > max_run:

                choices = [b for b in "ACGT" if b != seq[i]]
                new = random.choice(choices)

                result += new
                count = 1
                continue

        else:
            count = 1

        result += seq[i]

    return result


# =========================
# FULL DNA CONSTRAINT PIPELINE
# =========================

def apply_dna_constraints(seq):

    seq = balance_gc(seq)

    seq = prevent_homopolymers(seq)

    return seq