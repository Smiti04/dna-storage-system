import os
import zlib
import hashlib
from tqdm import tqdm
import reedsolo
from multiprocessing import Pool, cpu_count

from dna_constraints import apply_dna_constraints

# =========================
# REED SOLOMON
# =========================
rs = reedsolo.RSCodec(10)

# =========================
# HEX ↔ DNA MAP
# =========================
hex_to_dna_map = {
    "0": "AA","1": "AT","2": "AC","3": "AG",
    "4": "TA","5": "TT","6": "TC","7": "TG",
    "8": "CA","9": "CT","a": "CG","b": "CC",
    "c": "GA","d": "GT","e": "GG","f": "GC"
}

dna_to_hex_map = {v: k for k, v in hex_to_dna_map.items()}

# =========================
# PRIMERS
# =========================
FORWARD_PRIMER = "ACGTACGTAC"
REVERSE_PRIMER = "TGCATGCATG"

# =========================
# DNA MAPPING
# =========================
def hex_to_dna_encode(hex_string):
    return "".join(hex_to_dna_map[h] for h in hex_string)

def dna_to_hex_decode(dna):
    hex_string = ""
    for i in range(0, len(dna), 2):
        pair = dna[i:i+2]
        if pair not in dna_to_hex_map:
            raise ValueError("Invalid DNA")
        hex_string += dna_to_hex_map[pair]
    return hex_string

# =========================
# REED SOLOMON
# =========================
def encode_rs(fragment):
    return rs.encode(bytes.fromhex(fragment)).hex()

def decode_rs(fragment):
    try:
        return rs.decode(bytes.fromhex(fragment))[0].hex()
    except:
        return None

def parallel_rs_encode(fragments):
    with Pool(cpu_count()) as p:
        return list(tqdm(p.imap(encode_rs, fragments), total=len(fragments)))

# =========================
# XOR REDUNDANCY
# =========================
def create_xor_fragment(fragments):

    if len(fragments) < 2:
        return None

    xor_bytes = bytes.fromhex(fragments[0])

    for frag in fragments[1:]:
        b = bytes.fromhex(frag)

        if len(b) < len(xor_bytes):
            b += bytes(len(xor_bytes) - len(b))

        xor_bytes = bytes(a ^ b for a, b in zip(xor_bytes, b))

    return xor_bytes.hex()

# =========================
# FILE ENCODING
# =========================
def encode_file(file_path):

    print("\n[1/7] Encoding file...")

    filename = os.path.basename(file_path)
    dna_fragments = []
    index = 0
    hasher = hashlib.sha256()

    with open(file_path, "rb") as f:

        chunk_id = 0

        while True:
            chunk = f.read(1024 * 1024)  # 1MB
            if not chunk:
                break

            hasher.update(chunk)

            # ✅ STEP 1: Compression
            compressed = zlib.compress(chunk, 9)

            # ✅ STEP 2: Binary → Hex
            hex_data = compressed.hex()

            # ✅ STEP 3: Fragmentation
            fragment_size = 200
            fragments = [
                hex_data[i:i+fragment_size]
                for i in range(0, len(hex_data), fragment_size)
            ]

            # ✅ STEP 4: XOR redundancy
            xor_fragment = create_xor_fragment(fragments)
            if xor_fragment:
                fragments.append(xor_fragment)

            # ✅ STEP 5: Reed-Solomon
            fragments = parallel_rs_encode(fragments)

            # ✅ STEP 6: DNA Encoding
            for frag in fragments:

                dna = hex_to_dna_encode(frag)
                dna = apply_dna_constraints(dna)
                dna = FORWARD_PRIMER + dna + REVERSE_PRIMER

                dna_fragments.append(
                    f"{chunk_id}:{str(index).zfill(8)}|{dna}"
                )

                index += 1

            chunk_id += 1

    file_hash = hasher.hexdigest()

    print("[7/7] Encoding complete")

    return dna_fragments, file_hash, filename

# =========================
# FILE DECODING
# =========================
def decode_fragments(fragments, filename):

    print("\n[1/6] Decoding started")

    parsed = []

    # STEP 1: Parse all fragments globally
    for f in fragments:
        try:
            chunk_part, rest = f.split(":", 1)
            index_part, dna = rest.split("|", 1)

            chunk_id = int(chunk_part)
            index = int(index_part)

            if dna.startswith(FORWARD_PRIMER):
                dna = dna[len(FORWARD_PRIMER):]

            if dna.endswith(REVERSE_PRIMER):
                dna = dna[:-len(REVERSE_PRIMER)]

            parsed.append((chunk_id, index, dna))

        except:
            continue

    # 🔥 STEP 2: GLOBAL SORT (VERY IMPORTANT)
    parsed.sort(key=lambda x: (x[0], x[1]))

    full_hex = ""

    # STEP 3: Decode everything in order
    for chunk_id, index, dna in parsed:

        try:
            hex_frag = dna_to_hex_decode(dna)
            rs_decoded = decode_rs(hex_frag)

            if rs_decoded:
                full_hex += rs_decoded

        except:
            continue

    # Fix odd length
    if len(full_hex) % 2 != 0:
        full_hex = full_hex[:-1]

    # STEP 4: Convert to binary
    full_binary = bytes.fromhex(full_hex)

    # 🔥 STEP 5: SINGLE decompression
    try:
        final_data = zlib.decompress(full_binary)
        print("✅ Decompression successful")
    except Exception as e:
        print("❌ Decompression failed:", e)
        final_data = full_binary

    # STEP 6: Save file
    os.makedirs("output_files", exist_ok=True)
    path = os.path.join("output_files", filename)

    with open(path, "wb") as f:
        f.write(final_data)

    print("✅ File reconstructed:", path)

    return path
# =========================
# MERKLE TREE
# =========================
def compute_merkle_root(fragments):

    hashes = [hashlib.sha256(f.encode()).hexdigest() for f in fragments]

    if not hashes:
        return None

    while len(hashes) > 1:

        if len(hashes) % 2 == 1:
            hashes.append(hashes[-1])

        new_hashes = []

        for i in range(0, len(hashes), 2):
            combined = hashes[i] + hashes[i + 1]
            new_hash = hashlib.sha256(combined.encode()).hexdigest()
            new_hashes.append(new_hash)

        hashes = new_hashes

    return hashes[0]